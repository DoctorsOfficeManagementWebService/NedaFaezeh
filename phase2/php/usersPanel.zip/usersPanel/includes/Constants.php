<?php
define('DB_HOST','mysql');
define('DB_USER','fgatieco_doctorsoffice');
define('DB_PASS','mod024fUQtTLj70Z');
define('DB_NAME','fgatieco_doctorsoffice');
?>
